export { linkify } from "./linkify.js";
export { default as presets } from "./presets.js";
export type { LinkifyOptions } from "./types.js";
